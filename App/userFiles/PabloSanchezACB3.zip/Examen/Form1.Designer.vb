﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.j2 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.j1 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.c1 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.c2 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.c3 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.c4 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.c5 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.c6 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.c7 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.c8 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.c9 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.c10 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.c11 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.c12 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.c13 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.c0 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.RectangleShape14 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape13 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape12 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape9 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape8 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape7 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape6 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape11 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape10 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape5 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape4 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape3 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape2 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txtDado = New System.Windows.Forms.TextBox()
        Me.txtVueltas1 = New System.Windows.Forms.TextBox()
        Me.txtVueltas2 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.barraJugador1 = New System.Windows.Forms.ProgressBar()
        Me.barraJugador2 = New System.Windows.Forms.ProgressBar()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblJugador1 = New System.Windows.Forms.Label()
        Me.lblJugador2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.j2, Me.j1, Me.c1, Me.c2, Me.c3, Me.c4, Me.c5, Me.c6, Me.c7, Me.c8, Me.c9, Me.c10, Me.c11, Me.c12, Me.c13, Me.c0, Me.RectangleShape14, Me.RectangleShape13, Me.RectangleShape12, Me.RectangleShape9, Me.RectangleShape8, Me.RectangleShape7, Me.RectangleShape6, Me.RectangleShape11, Me.RectangleShape10, Me.RectangleShape5, Me.RectangleShape4, Me.RectangleShape3, Me.RectangleShape2, Me.RectangleShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(557, 558)
        Me.ShapeContainer1.TabIndex = 0
        Me.ShapeContainer1.TabStop = False
        '
        'j2
        '
        Me.j2.BackColor = System.Drawing.Color.Red
        Me.j2.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.j2.Location = New System.Drawing.Point(67, 335)
        Me.j2.Name = "j2"
        Me.j2.Size = New System.Drawing.Size(24, 23)
        '
        'j1
        '
        Me.j1.BackColor = System.Drawing.Color.Blue
        Me.j1.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.j1.Location = New System.Drawing.Point(47, 335)
        Me.j1.Name = "j1"
        Me.j1.Size = New System.Drawing.Size(24, 23)
        '
        'c1
        '
        Me.c1.Location = New System.Drawing.Point(55, 241)
        Me.c1.Name = "c1"
        Me.c1.Size = New System.Drawing.Size(24, 23)
        Me.c1.Visible = False
        '
        'c2
        '
        Me.c2.Location = New System.Drawing.Point(59, 148)
        Me.c2.Name = "c2"
        Me.c2.Size = New System.Drawing.Size(24, 23)
        Me.c2.Visible = False
        '
        'c3
        '
        Me.c3.Location = New System.Drawing.Point(57, 50)
        Me.c3.Name = "c3"
        Me.c3.Size = New System.Drawing.Size(24, 23)
        Me.c3.Visible = False
        '
        'c4
        '
        Me.c4.Location = New System.Drawing.Point(158, 51)
        Me.c4.Name = "c4"
        Me.c4.Size = New System.Drawing.Size(24, 23)
        Me.c4.Visible = False
        '
        'c5
        '
        Me.c5.Location = New System.Drawing.Point(256, 54)
        Me.c5.Name = "c5"
        Me.c5.Size = New System.Drawing.Size(24, 23)
        Me.c5.Visible = False
        '
        'c6
        '
        Me.c6.Location = New System.Drawing.Point(354, 53)
        Me.c6.Name = "c6"
        Me.c6.Size = New System.Drawing.Size(24, 23)
        Me.c6.Visible = False
        '
        'c7
        '
        Me.c7.Location = New System.Drawing.Point(455, 56)
        Me.c7.Name = "c7"
        Me.c7.Size = New System.Drawing.Size(24, 23)
        Me.c7.Visible = False
        '
        'c8
        '
        Me.c8.Location = New System.Drawing.Point(458, 149)
        Me.c8.Name = "c8"
        Me.c8.Size = New System.Drawing.Size(24, 23)
        Me.c8.Visible = False
        '
        'c9
        '
        Me.c9.Location = New System.Drawing.Point(457, 242)
        Me.c9.Name = "c9"
        Me.c9.Size = New System.Drawing.Size(24, 23)
        Me.c9.Visible = False
        '
        'c10
        '
        Me.c10.Location = New System.Drawing.Point(460, 335)
        Me.c10.Name = "c10"
        Me.c10.Size = New System.Drawing.Size(24, 23)
        Me.c10.Visible = False
        '
        'c11
        '
        Me.c11.Location = New System.Drawing.Point(361, 336)
        Me.c11.Name = "c11"
        Me.c11.Size = New System.Drawing.Size(24, 23)
        Me.c11.Visible = False
        '
        'c12
        '
        Me.c12.Location = New System.Drawing.Point(261, 335)
        Me.c12.Name = "c12"
        Me.c12.Size = New System.Drawing.Size(24, 23)
        Me.c12.Visible = False
        '
        'c13
        '
        Me.c13.Location = New System.Drawing.Point(158, 335)
        Me.c13.Name = "c13"
        Me.c13.Size = New System.Drawing.Size(24, 23)
        Me.c13.Visible = False
        '
        'c0
        '
        Me.c0.Location = New System.Drawing.Point(61, 334)
        Me.c0.Name = "c0"
        Me.c0.Size = New System.Drawing.Size(24, 23)
        Me.c0.Visible = False
        '
        'RectangleShape14
        '
        Me.RectangleShape14.Location = New System.Drawing.Point(324, 301)
        Me.RectangleShape14.Name = "RectangleShape14"
        Me.RectangleShape14.Size = New System.Drawing.Size(97, 91)
        '
        'RectangleShape13
        '
        Me.RectangleShape13.Location = New System.Drawing.Point(224, 301)
        Me.RectangleShape13.Name = "RectangleShape13"
        Me.RectangleShape13.Size = New System.Drawing.Size(97, 91)
        '
        'RectangleShape12
        '
        Me.RectangleShape12.Location = New System.Drawing.Point(124, 301)
        Me.RectangleShape12.Name = "RectangleShape12"
        Me.RectangleShape12.Size = New System.Drawing.Size(97, 91)
        '
        'RectangleShape9
        '
        Me.RectangleShape9.Location = New System.Drawing.Point(424, 301)
        Me.RectangleShape9.Name = "RectangleShape9"
        Me.RectangleShape9.Size = New System.Drawing.Size(97, 91)
        '
        'RectangleShape8
        '
        Me.RectangleShape8.Location = New System.Drawing.Point(424, 18)
        Me.RectangleShape8.Name = "RectangleShape8"
        Me.RectangleShape8.Size = New System.Drawing.Size(97, 91)
        '
        'RectangleShape7
        '
        Me.RectangleShape7.Location = New System.Drawing.Point(424, 112)
        Me.RectangleShape7.Name = "RectangleShape7"
        Me.RectangleShape7.Size = New System.Drawing.Size(97, 91)
        '
        'RectangleShape6
        '
        Me.RectangleShape6.Location = New System.Drawing.Point(424, 206)
        Me.RectangleShape6.Name = "RectangleShape6"
        Me.RectangleShape6.Size = New System.Drawing.Size(97, 91)
        '
        'RectangleShape11
        '
        Me.RectangleShape11.Location = New System.Drawing.Point(123, 18)
        Me.RectangleShape11.Name = "RectangleShape11"
        Me.RectangleShape11.Size = New System.Drawing.Size(97, 91)
        '
        'RectangleShape10
        '
        Me.RectangleShape10.Location = New System.Drawing.Point(223, 18)
        Me.RectangleShape10.Name = "RectangleShape10"
        Me.RectangleShape10.Size = New System.Drawing.Size(97, 91)
        '
        'RectangleShape5
        '
        Me.RectangleShape5.Location = New System.Drawing.Point(23, 206)
        Me.RectangleShape5.Name = "RectangleShape5"
        Me.RectangleShape5.Size = New System.Drawing.Size(97, 91)
        '
        'RectangleShape4
        '
        Me.RectangleShape4.Location = New System.Drawing.Point(23, 112)
        Me.RectangleShape4.Name = "RectangleShape4"
        Me.RectangleShape4.Size = New System.Drawing.Size(97, 91)
        '
        'RectangleShape3
        '
        Me.RectangleShape3.Location = New System.Drawing.Point(23, 18)
        Me.RectangleShape3.Name = "RectangleShape3"
        Me.RectangleShape3.Size = New System.Drawing.Size(97, 91)
        '
        'RectangleShape2
        '
        Me.RectangleShape2.Location = New System.Drawing.Point(323, 18)
        Me.RectangleShape2.Name = "RectangleShape2"
        Me.RectangleShape2.Size = New System.Drawing.Size(97, 91)
        '
        'RectangleShape1
        '
        Me.RectangleShape1.Location = New System.Drawing.Point(23, 301)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(97, 91)
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(337, 121)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Dado"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txtDado
        '
        Me.txtDado.Enabled = False
        Me.txtDado.Location = New System.Drawing.Point(337, 148)
        Me.txtDado.Name = "txtDado"
        Me.txtDado.Size = New System.Drawing.Size(75, 20)
        Me.txtDado.TabIndex = 2
        '
        'txtVueltas1
        '
        Me.txtVueltas1.Enabled = False
        Me.txtVueltas1.Location = New System.Drawing.Point(133, 266)
        Me.txtVueltas1.Name = "txtVueltas1"
        Me.txtVueltas1.Size = New System.Drawing.Size(100, 20)
        Me.txtVueltas1.TabIndex = 3
        '
        'txtVueltas2
        '
        Me.txtVueltas2.Enabled = False
        Me.txtVueltas2.Location = New System.Drawing.Point(239, 266)
        Me.txtVueltas2.Name = "txtVueltas2"
        Me.txtVueltas2.Size = New System.Drawing.Size(100, 20)
        Me.txtVueltas2.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(130, 242)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Vueltas Jugador 1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(236, 242)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(92, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Vueltas Jugador 2"
        '
        'barraJugador1
        '
        Me.barraJugador1.Location = New System.Drawing.Point(23, 469)
        Me.barraJugador1.Name = "barraJugador1"
        Me.barraJugador1.Size = New System.Drawing.Size(228, 23)
        Me.barraJugador1.TabIndex = 7
        '
        'barraJugador2
        '
        Me.barraJugador2.Location = New System.Drawing.Point(294, 469)
        Me.barraJugador2.Name = "barraJugador2"
        Me.barraJugador2.Size = New System.Drawing.Size(228, 23)
        Me.barraJugador2.TabIndex = 8
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(91, 453)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(93, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Energia Jugador 1"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(368, 453)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(93, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Energia Jugador 2"
        '
        'lblJugador1
        '
        Me.lblJugador1.AutoSize = True
        Me.lblJugador1.Location = New System.Drawing.Point(121, 498)
        Me.lblJugador1.Name = "lblJugador1"
        Me.lblJugador1.Size = New System.Drawing.Size(15, 13)
        Me.lblJugador1.TabIndex = 11
        Me.lblJugador1.Text = "%"
        '
        'lblJugador2
        '
        Me.lblJugador2.AutoSize = True
        Me.lblJugador2.Location = New System.Drawing.Point(404, 498)
        Me.lblJugador2.Name = "lblJugador2"
        Me.lblJugador2.Size = New System.Drawing.Size(15, 13)
        Me.lblJugador2.TabIndex = 12
        Me.lblJugador2.Text = "%"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(557, 558)
        Me.Controls.Add(Me.lblJugador2)
        Me.Controls.Add(Me.lblJugador1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.barraJugador2)
        Me.Controls.Add(Me.barraJugador1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtVueltas2)
        Me.Controls.Add(Me.txtVueltas1)
        Me.Controls.Add(Me.txtDado)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "Form1"
        Me.Text = "th"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ShapeContainer1 As PowerPacks.ShapeContainer
    Friend WithEvents c0 As PowerPacks.OvalShape
    Friend WithEvents RectangleShape14 As PowerPacks.RectangleShape
    Friend WithEvents RectangleShape13 As PowerPacks.RectangleShape
    Friend WithEvents RectangleShape12 As PowerPacks.RectangleShape
    Friend WithEvents RectangleShape9 As PowerPacks.RectangleShape
    Friend WithEvents RectangleShape8 As PowerPacks.RectangleShape
    Friend WithEvents RectangleShape7 As PowerPacks.RectangleShape
    Friend WithEvents RectangleShape6 As PowerPacks.RectangleShape
    Friend WithEvents RectangleShape11 As PowerPacks.RectangleShape
    Friend WithEvents RectangleShape10 As PowerPacks.RectangleShape
    Friend WithEvents RectangleShape5 As PowerPacks.RectangleShape
    Friend WithEvents RectangleShape4 As PowerPacks.RectangleShape
    Friend WithEvents RectangleShape3 As PowerPacks.RectangleShape
    Friend WithEvents RectangleShape2 As PowerPacks.RectangleShape
    Friend WithEvents RectangleShape1 As PowerPacks.RectangleShape
    Friend WithEvents c1 As PowerPacks.OvalShape
    Friend WithEvents c2 As PowerPacks.OvalShape
    Friend WithEvents c3 As PowerPacks.OvalShape
    Friend WithEvents c4 As PowerPacks.OvalShape
    Friend WithEvents c5 As PowerPacks.OvalShape
    Friend WithEvents c6 As PowerPacks.OvalShape
    Friend WithEvents c7 As PowerPacks.OvalShape
    Friend WithEvents c8 As PowerPacks.OvalShape
    Friend WithEvents c9 As PowerPacks.OvalShape
    Friend WithEvents c10 As PowerPacks.OvalShape
    Friend WithEvents c11 As PowerPacks.OvalShape
    Friend WithEvents c12 As PowerPacks.OvalShape
    Friend WithEvents c13 As PowerPacks.OvalShape
    Friend WithEvents Button1 As Button
    Friend WithEvents txtDado As TextBox
    Friend WithEvents j1 As PowerPacks.OvalShape
    Friend WithEvents j2 As PowerPacks.OvalShape
    Friend WithEvents txtVueltas1 As TextBox
    Friend WithEvents txtVueltas2 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents barraJugador1 As ProgressBar
    Friend WithEvents barraJugador2 As ProgressBar
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblJugador1 As Label
    Friend WithEvents lblJugador2 As Label
End Class
