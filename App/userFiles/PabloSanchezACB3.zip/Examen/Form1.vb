﻿Public Class Form1
	Private RND As New Random
	Private Const CANTIDAD_CASILLAS As Integer = 14
	Private Const CANTIDAD_JUGADORES As Integer = 2

	Class Jugador
		Public ficha As PowerPacks.OvalShape
		Public vueltas As Integer = 0
		Public nombre As String
		Public posicion As Integer = 0
		Public cajaVueltas As TextBox
		Public barra As ProgressBar
		Public label As Label

		Public Sub New(ficha As PowerPacks.OvalShape, cajaVueltas As TextBox, barra As ProgressBar, nombre As String, label As Label)
			MyBase.New()
			Me.cajaVueltas = cajaVueltas
			Me.barra = barra
			Me.ficha = ficha
			Me.nombre = nombre
			Me.label = label

			With Me.barra
				.Maximum = 100
				.Minimum = 0
				.Value = 100
			End With
		End Sub

		Public Sub mover(posiciones As Integer)
			Me.posicion += posiciones
			If Me.posicion >= CANTIDAD_CASILLAS Then
				vueltas += 1
				Me.posicion = Me.posicion Mod CANTIDAD_CASILLAS
				If Me.barra.Value + 10 > 100 Then
					Me.barra.Value = 100
				Else
					Me.barra.Value += 10
				End If
			End If
        End Sub

		Public Sub actualizarPosicion(ByRef casillas() As Casilla)
			Me.ficha.Location = casillas(Me.posicion).getLocation()
			Me.cajaVueltas.Text = vueltas.ToString()
			Me.label.Text = Me.barra.Value.ToString & "%"
		End Sub
	End Class

	Class Casilla
		Public ficha As PowerPacks.OvalShape
		Public modificador As Integer


		Public Sub New(ficha As PowerPacks.OvalShape, modificador As Integer)
			MyBase.New()
			Me.ficha = ficha
			Me.modificador = modificador
		End Sub

		Public Function getLocation()
			Return ficha.Location
		End Function

		Public Sub actuarEn(jugador As Jugador)
			If jugador.barra.Value + modificador > 100 Then
				jugador.barra.Value = 100
			ElseIf jugador.barra.Value + modificador < 0 Then
				jugador.barra.Value = 0
				MsgBox("El jugador " & jugador.nombre & "ha perdido la partida")
				End
			Else
				jugador.barra.Value += modificador
			End If
		End Sub
	End Class

	Private casillas() As Casilla
	Private jugadores() As Jugador
	Private j As Integer = 0

	Private Function dado()
		Return RND.Next(1, 6)
	End Function

	Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
		Me.Text = "Examen"
		Me.ShowIcon = False
		Me.casillas = New Casilla() {
			New Casilla(c0, 0),
			New Casilla(c1, 0),
			New Casilla(c2, -5),
			New Casilla(c3, 5),
			New Casilla(c4, 0),
			New Casilla(c5, 0),
			New Casilla(c6, -5),
			New Casilla(c7, 5),
			New Casilla(c8, -15),
			New Casilla(c9, -5),
			New Casilla(c10, 5),
			New Casilla(c11, -15),
			New Casilla(c12, -5),
			New Casilla(c13, 5)
		}
		jugadores = New Jugador() {
			New Jugador(j1, txtVueltas1, barraJugador1, "Jugador 1", lblJugador1),
			New Jugador(j2, txtVueltas2, barraJugador2, "Jugador 2", lblJugador2)
		}
	End Sub

	Private Sub actualizarDetalles()
		jugadores(j).actualizarPosicion(casillas)
	End Sub

	Private Sub siguienteTurno()
		j = (j + 1) Mod CANTIDAD_JUGADORES
	End Sub

	Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
		Dim tDado = dado()
		txtDado.Text = tDado.ToString()
		jugadores(j).mover(tDado)
		casillas(jugadores(j).posicion).actuarEn(jugadores(j))

		actualizarDetalles()
		siguienteTurno()
	End Sub
End Class
